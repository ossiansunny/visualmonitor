#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <net-snmp/agent/net-snmp-agent-includes.h>
#include "vmmib.h"

long    myint1    = 0; // add:initial = 1
char *mystring2 = 0;   // add:initial = NULL
char *mystring3 = 0;   // add:initial = NULL

void
init_vmmib(void)
{
    const oid myint1_oid[] = { 1,3,6,1,4,1,9999,1,1 };
    const oid mystring2_oid[] = { 1,3,6,1,4,1,9999,1,2 };
    const oid mystring3_oid[] = { 1,3,6,1,4,1,9999,1,3 };

  DEBUGMSGTL(("vmmib", "Initializing\n"));

    netsnmp_register_scalar(
        netsnmp_create_handler_registration("myint1", handle_myint1,
                               myint1_oid, OID_LENGTH(myint1_oid),
                               HANDLER_CAN_RWRITE
        ));
    netsnmp_register_scalar(
        netsnmp_create_handler_registration("mystring2", handle_mystring2,
                               mystring2_oid, OID_LENGTH(mystring2_oid),
                               HANDLER_CAN_RWRITE
        ));
    netsnmp_register_scalar(
        netsnmp_create_handler_registration("mystring3", handle_mystring3,
                               mystring3_oid, OID_LENGTH(mystring3_oid),
                               HANDLER_CAN_RWRITE
        ));
    mystring2=(char*)malloc(1);
    mystring3=(char*)malloc(1);
    mystring2[0]=0; // ""
    mystring3[0]=0; // ""
}

int
handle_myint1(netsnmp_mib_handler *handler,
                          netsnmp_handler_registration *reginfo,
                          netsnmp_agent_request_info   *reqinfo,
                          netsnmp_request_info         *requests)
{
    int ret;

    switch(reqinfo->mode) {

        case MODE_GET:
            snmp_set_var_typed_value(requests->requestvb, ASN_INTEGER,
                                     (u_char *) &myint1, // myint1 address
                                     sizeof(myint1) );   // myint1 size
            break;

        case MODE_SET_RESERVE1:
            ret = netsnmp_check_vb_type(requests->requestvb, ASN_INTEGER);
            if ( ret != SNMP_ERR_NOERROR ) {
                netsnmp_set_request_error(reqinfo, requests, ret );
            }
            break;

        case MODE_SET_RESERVE2:
            break;

        case MODE_SET_FREE:
            break;

        case MODE_SET_ACTION:
            break;

        case MODE_SET_COMMIT:
            myint1 = *requests->requestvb->val.integer; // update specifed value
            break;

        case MODE_SET_UNDO:
            break;

        default:
            snmp_log(LOG_ERR, "unknown mode (%d) in handle_myint1\n", reqinfo->mode );
            return SNMP_ERR_GENERR;
    }

    return SNMP_ERR_NOERROR;
}
int
handle_mystring2(netsnmp_mib_handler *handler,
                          netsnmp_handler_registration *reginfo,
                          netsnmp_agent_request_info   *reqinfo,
                          netsnmp_request_info         *requests)
{
    int ret;

    switch(reqinfo->mode) {

        case MODE_GET:
            snmp_set_var_typed_value(requests->requestvb, ASN_OCTET_STR,
                                     (u_char *)mystring2,  // mystring2 address
                                     strlen(mystring2)); // mystring2 size
            break;
        case MODE_SET_RESERVE1:
            ret = netsnmp_check_vb_type(requests->requestvb, ASN_OCTET_STR);
            if ( ret != SNMP_ERR_NOERROR ) {
                netsnmp_set_request_error(reqinfo, requests, ret );
            }
            break;

        case MODE_SET_RESERVE2:
            break;

        case MODE_SET_FREE:
            break;

        case MODE_SET_ACTION:
            break;

        case MODE_SET_COMMIT:
            free(mystring2);  // current value clear
            mystring2 = strdup((char*)requests->requestvb->val.string);  // update specified value
            break;

        case MODE_SET_UNDO:
            break;

        default:
            snmp_log(LOG_ERR, "unknown mode (%d) in handle_mystring2\n", reqinfo->mode );
            return SNMP_ERR_GENERR;
    }

    return SNMP_ERR_NOERROR;
}
int
handle_mystring3(netsnmp_mib_handler *handler,
                          netsnmp_handler_registration *reginfo,
                          netsnmp_agent_request_info   *reqinfo,
                          netsnmp_request_info         *requests)
{
    int ret;

    switch(reqinfo->mode) {

        case MODE_GET:
            snmp_set_var_typed_value(requests->requestvb, ASN_OCTET_STR,
                                     (u_char *)mystring3,  // mystring3 address
                                     strlen(mystring3)); // mystring3 size
            break;
        case MODE_SET_RESERVE1:
            ret = netsnmp_check_vb_type(requests->requestvb, ASN_OCTET_STR);
            if ( ret != SNMP_ERR_NOERROR ) {
                netsnmp_set_request_error(reqinfo, requests, ret );
            }
            break;

        case MODE_SET_RESERVE2:
            break;

        case MODE_SET_FREE:
            break;

        case MODE_SET_ACTION:
            break;

        case MODE_SET_COMMIT:
            free(mystring3);  // current value clear
            mystring3 = strdup((char*)requests->requestvb->val.string);  // update specified value
            break;

        case MODE_SET_UNDO:
            break;

        default:
            snmp_log(LOG_ERR, "unknown mode (%d) in handle_mystring3\n", reqinfo->mode );
            return SNMP_ERR_GENERR;
    }

    return SNMP_ERR_NOERROR;
}

#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <net-snmp/agent/net-snmp-agent-includes.h>
#include "vmmib.h"

long    myint1    = 0; // add:initial = 1
char *vmtcpport1 = 0;   // add:initial = NULL
char *vmtcpport2 = 0;   // add:initial = NULL
char *vmprocess1 = 0;   // add:initial = NULL
char *vmprocess2 = 0;   // add:initial = NULL

void
init_vmmib(void)
{
    const oid myint1_oid[] = { 1,3,6,1,4,1,999999,1,1 };
    const oid vmtcpport1_oid[] = { 1,3,6,1,4,1,999999,1,2 };
    const oid vmtcpport2_oid[] = { 1,3,6,1,4,1,999999,1,3 };
    const oid vmprocess1_oid[] = { 1,3,6,1,4,1,999999,1,4 };
    const oid vmprocess2_oid[] = { 1,3,6,1,4,1,999999,1,5 };

  DEBUGMSGTL(("vmmib", "Initializing\n"));

    netsnmp_register_scalar(
        netsnmp_create_handler_registration("myint1", handle_myint1,
                               myint1_oid, OID_LENGTH(myint1_oid),
                               HANDLER_CAN_RWRITE
        ));
    netsnmp_register_scalar(
        netsnmp_create_handler_registration("vmtcpport1", handle_vmtcpport1,
                               vmtcpport1_oid, OID_LENGTH(vmtcpport1_oid),
                               HANDLER_CAN_RWRITE
        ));
    netsnmp_register_scalar(
        netsnmp_create_handler_registration("vmtcpport2", handle_vmtcpport2,
                               vmtcpport2_oid, OID_LENGTH(vmtcpport2_oid),
                               HANDLER_CAN_RWRITE
        ));
    netsnmp_register_scalar(
        netsnmp_create_handler_registration("vmprocess1", handle_vmprocess1,
                               vmprocess1_oid, OID_LENGTH(vmprocess1_oid),
                               HANDLER_CAN_RWRITE
        ));
    netsnmp_register_scalar(
        netsnmp_create_handler_registration("vmprocess2", handle_vmprocess2,
                               vmprocess2_oid, OID_LENGTH(vmprocess2_oid),
                               HANDLER_CAN_RWRITE
        ));
    vmtcpport1=(char*)malloc(1);
    vmtcpport2=(char*)malloc(1);
    vmprocess1=(char*)malloc(1);
    vmprocess2=(char*)malloc(1);
    vmtcpport1[0]=0; // ""
    vmtcpport2[0]=0; // ""
    vmprocess1[0]=0; // ""
    vmprocess2[0]=0; // ""
}

int
handle_myint1(netsnmp_mib_handler *handler,
                          netsnmp_handler_registration *reginfo,
                          netsnmp_agent_request_info   *reqinfo,
                          netsnmp_request_info         *requests)
{
    int ret;

    switch(reqinfo->mode) {

        case MODE_GET:
            snmp_set_var_typed_value(requests->requestvb, ASN_INTEGER,
                                     (u_char *) &myint1, // myint1 address
                                     sizeof(myint1) );   // myint1 size
            break;

        case MODE_SET_RESERVE1:
            ret = netsnmp_check_vb_type(requests->requestvb, ASN_INTEGER);
            if ( ret != SNMP_ERR_NOERROR ) {
                netsnmp_set_request_error(reqinfo, requests, ret );
            }
            break;

        case MODE_SET_RESERVE2:
            break;

        case MODE_SET_FREE:
            break;

        case MODE_SET_ACTION:
            break;

        case MODE_SET_COMMIT:
            myint1 = *requests->requestvb->val.integer; // update specifed value
            break;

        case MODE_SET_UNDO:
            break;

        default:
            snmp_log(LOG_ERR, "unknown mode (%d) in handle_myint1\n", reqinfo->mode );
            return SNMP_ERR_GENERR;
    }

    return SNMP_ERR_NOERROR;
}
int
handle_vmtcpport1(netsnmp_mib_handler *handler,
                          netsnmp_handler_registration *reginfo,
                          netsnmp_agent_request_info   *reqinfo,
                          netsnmp_request_info         *requests)
{
    int ret;

    switch(reqinfo->mode) {

        case MODE_GET:
            snmp_set_var_typed_value(requests->requestvb, ASN_OCTET_STR,
                                     (u_char *)vmtcpport1,  // vmtcpport1 address
                                     strlen(vmtcpport1)); // vmtcpport1 size
            break;
        case MODE_SET_RESERVE1:
            ret = netsnmp_check_vb_type(requests->requestvb, ASN_OCTET_STR);
            if ( ret != SNMP_ERR_NOERROR ) {
                netsnmp_set_request_error(reqinfo, requests, ret );
            }
            break;

        case MODE_SET_RESERVE2:
            break;

        case MODE_SET_FREE:
            break;

        case MODE_SET_ACTION:
            break;

        case MODE_SET_COMMIT:
            free(vmtcpport1);  // current value clear
            vmtcpport1 = strdup((char*)requests->requestvb->val.string);  // update specified value
            break;

        case MODE_SET_UNDO:
            break;

        default:
            snmp_log(LOG_ERR, "unknown mode (%d) in handle_vmtcpport1\n", reqinfo->mode );
            return SNMP_ERR_GENERR;
    }

    return SNMP_ERR_NOERROR;
}
int
handle_vmtcpport2(netsnmp_mib_handler *handler,
                          netsnmp_handler_registration *reginfo,
                          netsnmp_agent_request_info   *reqinfo,
                          netsnmp_request_info         *requests)
{
    int ret;

    switch(reqinfo->mode) {

        case MODE_GET:
            snmp_set_var_typed_value(requests->requestvb, ASN_OCTET_STR,
                                     (u_char *)vmtcpport2,  // vmtcpport2 address
                                     strlen(vmtcpport2)); // vmtcpport2 size
            break;
        case MODE_SET_RESERVE1:
            ret = netsnmp_check_vb_type(requests->requestvb, ASN_OCTET_STR);
            if ( ret != SNMP_ERR_NOERROR ) {
                netsnmp_set_request_error(reqinfo, requests, ret );
            }
            break;

        case MODE_SET_RESERVE2:
            break;

        case MODE_SET_FREE:
            break;

        case MODE_SET_ACTION:
            break;

        case MODE_SET_COMMIT:
            free(vmtcpport2);  // current value clear
            vmtcpport2 = strdup((char*)requests->requestvb->val.string);  // update specified value
            break;

        case MODE_SET_UNDO:
            break;

        default:
            snmp_log(LOG_ERR, "unknown mode (%d) in handle_vmtcpport2\n", reqinfo->mode );
            return SNMP_ERR_GENERR;
    }

    return SNMP_ERR_NOERROR;
}
int
handle_vmprocess1(netsnmp_mib_handler *handler,
                          netsnmp_handler_registration *reginfo,
                          netsnmp_agent_request_info   *reqinfo,
                          netsnmp_request_info         *requests)
{
    int ret;

    switch(reqinfo->mode) {

        case MODE_GET:
            snmp_set_var_typed_value(requests->requestvb, ASN_OCTET_STR,
                                     (u_char *)vmprocess1,  // vmprocess1 address
                                     strlen(vmprocess1)); // vmprocess1 size
            break;
        case MODE_SET_RESERVE1:
            ret = netsnmp_check_vb_type(requests->requestvb, ASN_OCTET_STR);
            if ( ret != SNMP_ERR_NOERROR ) {
                netsnmp_set_request_error(reqinfo, requests, ret );
            }
            break;

        case MODE_SET_RESERVE2:
            break;

        case MODE_SET_FREE:
            break;

        case MODE_SET_ACTION:
            break;

        case MODE_SET_COMMIT:
            free(vmprocess1);  // current value clear
            vmprocess1 = strdup((char*)requests->requestvb->val.string);  // update specified value
            break;

        case MODE_SET_UNDO:
            break;

        default:
            snmp_log(LOG_ERR, "unknown mode (%d) in handle_vmprocess1\n", reqinfo->mode );
            return SNMP_ERR_GENERR;
    }

    return SNMP_ERR_NOERROR;
}
int
handle_vmprocess2(netsnmp_mib_handler *handler,
                          netsnmp_handler_registration *reginfo,
                          netsnmp_agent_request_info   *reqinfo,
                          netsnmp_request_info         *requests)
{
    int ret;

    switch(reqinfo->mode) {

        case MODE_GET:
            snmp_set_var_typed_value(requests->requestvb, ASN_OCTET_STR,
                                     (u_char *)vmprocess2,  // vmprocess2 address
                                     strlen(vmprocess2)); // vmprocess2 size
            break;
        case MODE_SET_RESERVE1:
            ret = netsnmp_check_vb_type(requests->requestvb, ASN_OCTET_STR);
            if ( ret != SNMP_ERR_NOERROR ) {
                netsnmp_set_request_error(reqinfo, requests, ret );
            }
            break;

        case MODE_SET_RESERVE2:
            break;

        case MODE_SET_FREE:
            break;

        case MODE_SET_ACTION:
            break;

        case MODE_SET_COMMIT:
            free(vmprocess2);  // current value clear
            vmprocess2 = strdup((char*)requests->requestvb->val.string);  // update specified value
            break;

        case MODE_SET_UNDO:
            break;

        default:
            snmp_log(LOG_ERR, "unknown mode (%d) in handle_vmprocess2\n", reqinfo->mode );
            return SNMP_ERR_GENERR;
    }

    return SNMP_ERR_NOERROR;
}

###
## get process list from vmmib 999999.1.4.0 like httpd;ssh and save processes
###
ans=""
processes=`snmpget -v1 -cprivate localhost .1.3.6.1.4.1.999999.1.4.0 | awk '{print $4}' | sed 's/;/ /g' | sed 's/\"//g'`
#echo $processes
if [ -z "$processes" ]
then
  ans='empty'
else
###
## compare target process and running process and save to vmmib 999999.1.5.0
##
  #echo $processes
  procs=""
  for item in ${processes[@]}
  do
    prc=`ps -ef | grep $item | grep -v grep | grep -v snmptrap | wc -l`
    if [ $prc -eq 0 ]
    then
      procs=`echo "$procs$item;"`
      #echo $procs
    fi
  done
  if [ -z $procs ]
  then
    ans='allok'
  else
    ans=`echo $procs | sed 's/;$//'`
  fi
fi
echo $ans
snmpset -v1 -cprivate localhost .1.3.6.1.4.1.999999.1.5.0 s "$ans" &>> /dev/null

###
## get tcp port from vmmib 999999.1.2.0 like 80;443 and save to ports
###
ports=`snmpget -v1 -cprivate localhost .1.3.6.1.4.1.999999.1.2.0 | awk '{print $4}' | sed 's/;/ /g' | sed 's/\"//g'`
if [ -z "$ports" ]
then
  ans='empty'
else
###
## get tcp listen port to openports by netstat command
###
  openports=`netstat -nlt4 | grep LISTEN | awk '{print $4}' | awk 'BEGIN{FS=":"}{print $2}'`
  openports+=(`netstat -nlt6 | grep LISTEN | awk '{print $4}' | awk 'BEGIN{FS=":::"}{print $2}'`)
  #echo "input ports:$ports"
  rtnport=""
###
## compare target port and listen port and save to vmmib 999999.1.3.0 
###
  for reqport in ${ports[@]}
  do
    findsw=0
    for openport in ${openports[@]}
    do
      #echo "compare req:$reqport open:$openport"
      if [ $reqport -eq $openport ]
      then
        findsw=1
        break
      fi
    done
    if [ $findsw -eq 0 ]
    then
      rtnport=`echo "$rtnport$reqport;"`
    fi
  done
  if [ -z $rtnport ]
  then
    ans='allok'
  else
    ans=`echo $rtnport | sed 's/;$//'`
  fi
fi
echo $ans
snmpset -v1 -cprivate localhost .1.3.6.1.4.1.999999.1.3.0 s "$ans" &>> /dev/null
